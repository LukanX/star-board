"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/generate-image-background.ts
var generate_image_background_exports = {};
__export(generate_image_background_exports, {
  default: () => handler
});
module.exports = __toCommonJS(generate_image_background_exports);

// lib/ai/client.ts
var import_openai = __toESM(require("openai"));
var import_zod2 = require("openai/helpers/zod");
var import_zod3 = require("zod");

// lib/env.ts
var import_zod = require("zod");
var publicEnvSchema = import_zod.z.object({
  NEXT_PUBLIC_SUPABASE_URL: import_zod.z.string().url().optional(),
  NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: import_zod.z.string().min(1).optional(),
  NEXT_PUBLIC_APP_URL: import_zod.z.string().url().optional()
}).superRefine((env, context) => {
  const hasUrl = Boolean(env.NEXT_PUBLIC_SUPABASE_URL);
  const hasKey = Boolean(env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY);
  if (hasUrl !== hasKey) {
    context.addIssue({
      code: import_zod.z.ZodIssueCode.custom,
      message: "Supabase URL and publishable key must be configured together.",
      path: [hasUrl ? "NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY" : "NEXT_PUBLIC_SUPABASE_URL"]
    });
  }
});
var serverEnvSchema = publicEnvSchema.extend({
  SUPABASE_SECRET_KEY: import_zod.z.string().min(1).optional(),
  OPENROUTER_API_KEY: import_zod.z.string().min(1).optional(),
  OPENROUTER_SITE_URL: import_zod.z.string().url().optional(),
  OPENROUTER_APP_NAME: import_zod.z.string().min(1).optional(),
  OPENROUTER_TEXT_MODEL: import_zod.z.string().min(1).default("openai/gpt-4o-mini"),
  OPENROUTER_IMAGE_MODEL: import_zod.z.string().min(1).default("openai/gpt-image-1"),
  NETLIFY_IMAGE_GENERATION: import_zod.z.enum(["sync", "background"]).default("sync")
});
function parseEnvironment(schema, values) {
  const result = schema.safeParse(values);
  if (!result.success) {
    const details = result.error.issues.map((issue) => `${issue.path.join(".")}: ${issue.message}`).join("; ");
    throw new Error(`Invalid environment configuration. ${details}`);
  }
  return result.data;
}
function getServerEnv() {
  return parseEnvironment(serverEnvSchema, {
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    SUPABASE_SECRET_KEY: process.env.SUPABASE_SECRET_KEY,
    OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY,
    OPENROUTER_SITE_URL: process.env.OPENROUTER_SITE_URL,
    OPENROUTER_APP_NAME: process.env.OPENROUTER_APP_NAME,
    OPENROUTER_TEXT_MODEL: process.env.OPENROUTER_TEXT_MODEL,
    OPENROUTER_IMAGE_MODEL: process.env.OPENROUTER_IMAGE_MODEL,
    NETLIFY_IMAGE_GENERATION: process.env.NETLIFY_IMAGE_GENERATION
  });
}

// lib/ai/errors.ts
var AiProviderError = class extends Error {
  constructor(message, options = {}) {
    super(message);
    this.name = "AiProviderError";
    this.status = options.status ?? null;
    this.requestId = options.requestId ?? null;
    this.retryAfter = options.retryAfter ?? null;
    this.providerBody = options.providerBody ?? null;
    this.generationId = options.generationId ?? null;
  }
};
var providerBodyLimit = 2e3;
var sensitiveProviderKey = /api[_-]?key|authorization|cookie|password|passphrase|prompt|secret|token/i;
function isRecord(value) {
  return Boolean(value) && typeof value === "object";
}
function redactProviderValue(value, depth = 0) {
  if (depth > 4) return "[truncated]";
  if (typeof value === "string") return value.slice(0, providerBodyLimit);
  if (Array.isArray(value)) return value.slice(0, 20).map((item) => redactProviderValue(item, depth + 1));
  if (!isRecord(value)) return value;
  return Object.fromEntries(Object.entries(value).slice(0, 40).map(([key, nestedValue]) => [
    key,
    sensitiveProviderKey.test(key) ? "[redacted]" : redactProviderValue(nestedValue, depth + 1)
  ]));
}
function serializeProviderBody(value) {
  if (value === null || value === void 0) return null;
  try {
    const sanitized = redactProviderValue(value);
    const serialized = typeof sanitized === "string" ? sanitized : JSON.stringify(sanitized);
    return serialized?.slice(0, providerBodyLimit) || null;
  } catch {
    return null;
  }
}
function extractProviderGenerationId(value) {
  if (!isRecord(value)) return null;
  for (const key of ["generation_id", "generationId", "id"]) {
    if (typeof value[key] === "string" && value[key].trim()) return value[key].trim();
  }
  for (const key of ["error", "response", "data"]) {
    const generationId = extractProviderGenerationId(value[key]);
    if (generationId) return generationId;
  }
  return null;
}
function extractProviderMessage(value) {
  if (typeof value === "string") return value.trim().slice(0, 500) || null;
  if (!isRecord(value)) return null;
  for (const key of ["message", "detail", "error"]) {
    const message = extractProviderMessage(value[key]);
    if (message) return message;
  }
  return null;
}
function getAiProviderFailure(error, fallback) {
  const providerError = error instanceof AiProviderError ? error : null;
  const status = providerError?.status && providerError.status >= 400 && providerError.status <= 599 ? providerError.status : 503;
  return {
    message: providerError?.message ?? fallback,
    status,
    requestId: providerError?.requestId ?? null,
    retryAfter: providerError?.retryAfter ?? null
  };
}
function logAiProviderFailure(error, context) {
  if (!(error instanceof AiProviderError)) return;
  console.error(JSON.stringify({
    event: "ai_provider_failure",
    ...context,
    status: error.status,
    requestId: error.requestId,
    generationId: error.generationId,
    retryAfter: error.retryAfter,
    providerBody: error.providerBody
  }));
}

// lib/ai/image-options.ts
var imageAspectRatioValues = ["1:1", "3:4", "4:3", "16:9"];
var imageSizeValues = [
  "1024x1024",
  "2048x2048",
  "768x1024",
  "1536x2048",
  "1024x768",
  "2048x1536",
  "1024x576",
  "2048x1152"
];
var imageSizeOptions = {
  "1:1": [
    { value: "1024x1024", label: "1024 x 1024 (1K)", tier: "1K" },
    { value: "2048x2048", label: "2048 x 2048 (2K)", tier: "2K" }
  ],
  "3:4": [
    { value: "768x1024", label: "768 x 1024 (1K)", tier: "1K" },
    { value: "1536x2048", label: "1536 x 2048 (2K)", tier: "2K" }
  ],
  "4:3": [
    { value: "1024x768", label: "1024 x 768 (1K)", tier: "1K" },
    { value: "2048x1536", label: "2048 x 1536 (2K)", tier: "2K" }
  ],
  "16:9": [
    { value: "1024x576", label: "1024 x 576 (1K)", tier: "1K" },
    { value: "2048x1152", label: "2048 x 1152 (2K)", tier: "2K" }
  ]
};
var defaultImageAspectRatio = "1:1";
var defaultImageSize = "1024x1024";

// lib/ai/client.ts
var openRouterBaseUrl = "https://openrouter.ai/api/v1";
var defaultImageGenerationTimeoutMs = 2 * 60 * 1e3;
var imageGenerationResponseSchema = import_zod3.z.object({
  id: import_zod3.z.string().min(1).optional(),
  data: import_zod3.z.array(import_zod3.z.object({
    b64_json: import_zod3.z.string().min(1).nullable().optional(),
    url: import_zod3.z.string().url().nullable().optional(),
    media_type: import_zod3.z.string().regex(/^image\//).optional()
  })).min(1),
  model: import_zod3.z.string().min(1).optional(),
  usage: import_zod3.z.object({
    prompt_tokens: import_zod3.z.number().int().nonnegative().optional(),
    completion_tokens: import_zod3.z.number().int().nonnegative().optional(),
    total_tokens: import_zod3.z.number().int().nonnegative().optional(),
    cost: import_zod3.z.number().nonnegative().optional()
  }).optional()
});
async function generateImage(prompt, requestedModel, options = {}) {
  const env = getServerEnv();
  if (!env.OPENROUTER_API_KEY) {
    throw new Error("OpenRouter is not configured. Add OPENROUTER_API_KEY to the server environment.");
  }
  const headers = {
    Authorization: `Bearer ${env.OPENROUTER_API_KEY}`,
    "Content-Type": "application/json"
  };
  if (env.OPENROUTER_SITE_URL) headers["HTTP-Referer"] = env.OPENROUTER_SITE_URL;
  if (env.OPENROUTER_APP_NAME) headers["X-Title"] = env.OPENROUTER_APP_NAME;
  let response;
  try {
    response = await fetch(`${openRouterBaseUrl}/images`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: requestedModel,
        prompt,
        aspect_ratio: options.aspectRatio ?? defaultImageAspectRatio,
        size: options.size ?? defaultImageSize,
        output_format: "png"
      }),
      signal: AbortSignal.timeout(options.timeoutMs ?? defaultImageGenerationTimeoutMs)
    });
  } catch (error) {
    if (error instanceof Error && (error.name === "AbortError" || error.name === "TimeoutError")) {
      throw new AiProviderError("OpenRouter image generation timed out. Try again, or use background generation for long-running requests.", { status: 504 });
    }
    throw error;
  }
  if (!response.ok) {
    let providerMessage = null;
    let providerBody = null;
    let providerPayload = null;
    try {
      providerPayload = await response.clone().json();
      providerMessage = extractProviderMessage(providerPayload);
      providerBody = serializeProviderBody(providerPayload);
    } catch {
      const body = await response.clone().text();
      providerMessage = extractProviderMessage(body);
      providerBody = serializeProviderBody(body);
    }
    throw new AiProviderError(providerMessage ? `OpenRouter image generation failed. ${providerMessage}` : "OpenRouter image generation failed.", {
      status: response.status,
      requestId: response.headers.get("x-request-id") ?? response.headers.get("x-openrouter-request-id"),
      retryAfter: response.headers.get("retry-after"),
      providerBody,
      generationId: extractProviderGenerationId(providerPayload)
    });
  }
  const payload = imageGenerationResponseSchema.safeParse(await response.json());
  if (!payload.success) throw new Error("OpenRouter returned an invalid image response.");
  const image = payload.data.data[0];
  if (!image.b64_json && !image.url) throw new Error("The AI provider returned no image data.");
  return {
    image: {
      base64: image.b64_json ?? null,
      url: image.url ?? null,
      mediaType: image.media_type ?? "image/png"
    },
    model: payload.data.model ?? requestedModel,
    generationId: payload.data.id,
    usage: payload.data.usage ? {
      inputTokens: payload.data.usage.prompt_tokens,
      outputTokens: payload.data.usage.completion_tokens,
      cost: payload.data.usage.cost
    } : void 0
  };
}

// lib/ai/image-jobs.ts
var import_node_crypto = require("node:crypto");

// lib/validation/image.ts
var import_zod4 = require("zod");
var imagePromptMaxLength = 3e3;
var imageGenerationInputSchema = import_zod4.z.object({
  campaignId: import_zod4.z.string().uuid(),
  mode: import_zod4.z.enum(["create", "refine"]),
  targetKind: import_zod4.z.enum(["character", "npc", "faction", "job", "place"]),
  model: import_zod4.z.string().trim().min(1).max(160).optional(),
  subject: import_zod4.z.string().trim().min(1).max(1200),
  aspectRatio: import_zod4.z.enum(imageAspectRatioValues).default(defaultImageAspectRatio),
  size: import_zod4.z.enum(imageSizeValues).default(defaultImageSize),
  campaignStyle: import_zod4.z.string().trim().max(600).optional(),
  refinement: import_zod4.z.string().trim().max(600).optional(),
  currentPrompt: import_zod4.z.string().trim().max(imagePromptMaxLength).optional()
}).superRefine(({ aspectRatio, size }, context) => {
  if (!imageSizeOptions[aspectRatio].some((option) => option.value === size)) {
    context.addIssue({ code: "custom", path: ["size"], message: `Size ${size} does not match aspect ratio ${aspectRatio}.` });
  }
});
var imageBackgroundJobSchema = import_zod4.z.object({
  generationRunId: import_zod4.z.string().uuid(),
  prompt: import_zod4.z.string().trim().min(1).max(imagePromptMaxLength),
  model: import_zod4.z.string().trim().min(1).max(160),
  aspectRatio: import_zod4.z.enum(imageAspectRatioValues),
  size: import_zod4.z.enum(imageSizeValues)
}).superRefine(({ aspectRatio, size }, context) => {
  if (!imageSizeOptions[aspectRatio].some((option) => option.value === size)) {
    context.addIssue({ code: "custom", path: ["size"], message: `Size ${size} does not match aspect ratio ${aspectRatio}.` });
  }
});
var imageDraftSchema = import_zod4.z.object({
  generationRunId: import_zod4.z.string().uuid(),
  targetKind: import_zod4.z.enum(["character", "npc", "faction", "job", "place"]),
  mode: import_zod4.z.enum(["create", "refine"]),
  subject: import_zod4.z.string().trim().min(1).max(1200),
  aspectRatio: import_zod4.z.enum(imageAspectRatioValues),
  size: import_zod4.z.enum(imageSizeValues),
  prompt: import_zod4.z.string().trim().min(1).max(imagePromptMaxLength),
  image: import_zod4.z.object({
    base64: import_zod4.z.string().min(1).nullable(),
    url: import_zod4.z.string().url().nullable(),
    mediaType: import_zod4.z.enum(["image/png", "image/jpeg", "image/webp"])
  }).refine(({ base64, url }) => Boolean(base64 || url), {
    message: "An image draft must include base64 data or a URL."
  }),
  provider: import_zod4.z.literal("openrouter"),
  model: import_zod4.z.string().min(1),
  createdAt: import_zod4.z.string().datetime()
});

// lib/ai/image-jobs.ts
function createImageBackgroundSignature(job, secret) {
  return (0, import_node_crypto.createHmac)("sha256", secret).update(JSON.stringify(job)).digest("hex");
}
function verifyImageBackgroundSignature(job, signature, secret) {
  if (!signature) return false;
  const expected = createImageBackgroundSignature(job, secret);
  const received = Buffer.from(signature, "hex");
  const expectedBytes = Buffer.from(expected, "hex");
  return received.length === expectedBytes.length && (0, import_node_crypto.timingSafeEqual)(received, expectedBytes);
}
function parseImageBackgroundJob(body) {
  return imageBackgroundJobSchema.safeParse(body);
}

// lib/validation/art.ts
var import_zod5 = require("zod");
var campaignArtKindSchema = import_zod5.z.enum(["character", "npc", "faction", "job", "place"]);
var campaignArtPathSchema = import_zod5.z.string().trim().min(1).max(500).refine(
  (value) => value.split("/").length === 3 && !value.includes("..") && !value.includes("\\"),
  "Campaign art path is invalid."
);
var campaignArtMaxBytes = 5 * 1024 * 1024;

// lib/storage/campaign-art.ts
var campaignArtBucket = "campaign-art";

// lib/supabase/service.ts
var import_supabase_js = require("@supabase/supabase-js");
function getSupabaseServiceRoleClient() {
  const env = getServerEnv();
  if (!env.NEXT_PUBLIC_SUPABASE_URL || !env.SUPABASE_SECRET_KEY) {
    throw new Error("Supabase secret-key access is not configured.");
  }
  return (0, import_supabase_js.createClient)(env.NEXT_PUBLIC_SUPABASE_URL, env.SUPABASE_SECRET_KEY, {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  });
}

// netlify/functions/generate-image-background.ts
var imageMediaTypes = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp"
};
function truncate(value, maxLength) {
  return value.length > maxLength ? `${value.slice(0, maxLength - 1)}...` : value;
}
async function getStoredImage(image) {
  if (image.base64) {
    const mediaType2 = imageMediaTypes[image.mediaType] ? image.mediaType : null;
    if (!mediaType2) throw new Error("The AI provider returned an unsupported image type.");
    return { body: new Blob([Buffer.from(image.base64, "base64")], { type: mediaType2 }), mediaType: mediaType2 };
  }
  if (!image.url) throw new Error("The AI provider returned no image data.");
  const response = await fetch(image.url, { signal: AbortSignal.timeout(6e4) });
  if (!response.ok) throw new Error(`The generated image could not be downloaded (HTTP ${response.status}).`);
  const responseMediaType = response.headers.get("content-type")?.split(";", 1)[0]?.toLowerCase();
  const declaredMediaType = image.mediaType in imageMediaTypes ? image.mediaType : null;
  const mediaType = responseMediaType && responseMediaType in imageMediaTypes ? responseMediaType : declaredMediaType;
  if (!mediaType) throw new Error("The generated image has an unsupported media type.");
  return { body: await response.blob(), mediaType };
}
async function failRun(supabase, generationRunId, error) {
  const message = getAiProviderFailure(error, "Art generation is temporarily unavailable.").message;
  await supabase.from("ai_generation_runs").update({ status: "failed", error_message: truncate(message, 500) }).eq("id", generationRunId);
}
async function handler(request) {
  if (request.method !== "POST") return new Response("Method Not Allowed", { status: 405 });
  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }
  const input = parseImageBackgroundJob(body);
  if (!input.success) return Response.json({ error: "Image background job is invalid." }, { status: 400 });
  const env = getServerEnv();
  if (!env.SUPABASE_SECRET_KEY || !verifyImageBackgroundSignature(input.data, request.headers.get("X-Star-Board-Image-Signature"), env.SUPABASE_SECRET_KEY)) {
    return Response.json({ error: "Image background job is unauthorized." }, { status: 401 });
  }
  let supabase;
  try {
    supabase = getSupabaseServiceRoleClient();
  } catch {
    return Response.json({ error: "Image background storage is not configured." }, { status: 503 });
  }
  const { data: claimedRun, error: claimError } = await supabase.from("ai_generation_runs").update({ status: "running", error_message: null }).eq("id", input.data.generationRunId).eq("status", "pending").select("id, campaign_id, requested_by").maybeSingle();
  if (claimError) return Response.json({ error: "Image background job could not be claimed." }, { status: 503 });
  if (!claimedRun) return new Response(null, { status: 202 });
  try {
    const response = await generateImage(input.data.prompt, input.data.model, { aspectRatio: input.data.aspectRatio, size: input.data.size, timeoutMs: 14 * 60 * 1e3 });
    const storedImage = await getStoredImage(response.image);
    const path = `${claimedRun.campaign_id}/${claimedRun.requested_by}/image-${claimedRun.id}.${imageMediaTypes[storedImage.mediaType]}`;
    const { error: uploadError } = await supabase.storage.from(campaignArtBucket).upload(path, storedImage.body, {
      cacheControl: "3600",
      contentType: storedImage.mediaType,
      upsert: false
    });
    if (uploadError) throw new Error("The generated image could not be stored.");
    const { error: completeError } = await supabase.from("ai_generation_runs").update({
      status: "complete",
      effective_model: response.model,
      generation_id: response.generationId,
      input_tokens: response.usage?.inputTokens,
      output_tokens: response.usage?.outputTokens,
      cost_usd: response.usage?.cost,
      image_path: path,
      image_media_type: storedImage.mediaType,
      error_message: null
    }).eq("id", claimedRun.id);
    if (completeError) {
      await supabase.storage.from(campaignArtBucket).remove([path]);
      throw new Error("Image generation metadata could not be saved.");
    }
  } catch (error) {
    logAiProviderFailure(error, { kind: "image", campaignId: claimedRun.campaign_id, userId: claimedRun.requested_by, model: input.data.model });
    await failRun(supabase, claimedRun.id, error);
  }
  return new Response(null, { status: 202 });
}
